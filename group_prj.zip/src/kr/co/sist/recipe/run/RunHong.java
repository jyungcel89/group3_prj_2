package kr.co.sist.recipe.run;

import kr.co.sist.recipe.view.LogInForm;

public class RunHong {

	public static void main(String[] args) {
		new LogInForm();
	}//main

}//class
